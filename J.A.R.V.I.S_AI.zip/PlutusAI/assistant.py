import speech_recognition as sr
import win32com.client
import webbrowser
import datetime
import wikipedia
import traceback
import os
import subprocess

# Try to import Gemini AI, but handle if API key is missing
try:
    import google.generativeai as genai

    # Configure Gemini API
    API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyAEbvT89980CPc6VpqLL87pecYaTeevqhM")
    if API_KEY:
        genai.configure(api_key=API_KEY)
        GEMINI_AVAILABLE = True
    else:
        print("Warning: GEMINI_API_KEY environment variable not set.")
        GEMINI_AVAILABLE = False
except ImportError:
    print("Warning: google.generativeai package not installed.")
    GEMINI_AVAILABLE = False

# Text-to-Speech engine
try:
    speaker = win32com.client.Dispatch("SAPI.SpVoice")
    TTS_AVAILABLE = True
except:
    print("Warning: Text-to-speech engine could not be initialized.")
    TTS_AVAILABLE = False

chat_history = ""
is_speaking = False


def stop_speech():
    """Stop the TTS engine from speaking"""
    global is_speaking
    try:
        if TTS_AVAILABLE:
            speaker.Speak("", 2)  # SVSFPurgeBeforeSpeak flag = 2
            is_speaking = False
        return {"status": "success", "message": "Speech stopped"}
    except Exception as e:
        print(f"Error stopping speech: {e}")
        return {"status": "error", "message": str(e)}


def say(text):
    """Speak text and return it (for web interface)"""
    global is_speaking
    try:
        if TTS_AVAILABLE:
            is_speaking = True
            speaker.Speak(text)
            is_speaking = False
        return text
    except Exception as e:
        print(f"TTS error: {e}")
        is_speaking = False
        return text


def take_command():
    """Listen for voice command"""
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 0.6
            audio = r.listen(source)
            try:
                query = r.recognize_google(audio, language="en-in")
                print(f"User said: {query}")

                # Check if this is a command to stop speaking
                if "stop speaking" in query.lower() or "shut up" in query.lower() or "be quiet" in query.lower():
                    stop_speech()
                    return None

                return query
            except sr.UnknownValueError:
                print("Could not understand the audio.")
                return None
            except sr.RequestError:
                print("Could not request results.")
                return None
    except Exception as e:
        print(f"Error with microphone: {e}")
        return None


def chat(query):
    """Process a chat query and return response"""
    global chat_history
    chat_history += f"You: {query}\n"

    try:
        if GEMINI_AVAILABLE:
            model = genai.GenerativeModel("gemini-1.5-flash")
            response = model.generate_content(query)
            reply = response.text if hasattr(response, "text") else "Sorry, I couldn't process that."
        else:
            # Fallback response if Gemini is not available
            reply = f"I received your message: '{query}'. Gemini AI is not currently available."

        chat_history += f"Assistant: {reply}\n"
        print(chat_history)
        return say(reply)
    except Exception as e:
        print(f"Chat error: {e}")
        print(traceback.format_exc())
        error_msg = "Sorry, I couldn't process that request right now."
        return say(error_msg)


def search_wikipedia(query=None):
    """Search Wikipedia for information"""
    if not query:
        return say("Please provide a search query")

    try:
        result = wikipedia.summary(query, sentences=2)
        print(f"Wikipedia: {result}")
        return say(result)
    except wikipedia.exceptions.PageError:
        return say(f"Sorry, I couldn't find information about '{query}' on Wikipedia.")
    except wikipedia.exceptions.DisambiguationError:
        return say(f"There are multiple results for '{query}'. Please be more specific.")
    except Exception as e:
        print(f"Wikipedia search error: {e}")
        return say(f"I had trouble searching Wikipedia for '{query}'.")


def system_power_control(command_text):
    """Control system power (shutdown/restart)"""
    try:
        if "shutdown" in command_text:
            os.system("shutdown /s /t 1")
            return say("Shutting down the system.")
        elif "restart" in command_text:
            os.system("shutdown /r /t 1")
            return say("Restarting the system.")
        return say("No power command recognized.")
    except Exception as e:
        print(f"System power control error: {e}")
        return say("I had trouble executing that system command.")


def open_system_tool(command_text):
    """Open system tools and applications"""
    try:
        response = "Opening requested application"

        if "notepad" in command_text:
            subprocess.Popen("notepad")
            response = "Opening Notepad."
        elif "calculator" in command_text:
            subprocess.Popen("calc")
            response = "Opening Calculator."
        elif "control panel" in command_text:
            subprocess.Popen("control")
            response = "Opening Control Panel."
        elif "settings" in command_text:
            subprocess.Popen("start ms-settings:", shell=True)
            response = "Opening Settings."
        elif "task manager" in command_text:
            subprocess.Popen("taskmgr")
            response = "Opening Task Manager."
        elif "whatsapp" in command_text:
            subprocess.Popen("start whatsapp:", shell=True)
            response = "Opening WhatsApp."
        elif "word" in command_text:
            subprocess.Popen("start winword", shell=True)
            response = "Opening Microsoft Word."
        elif "excel" in command_text:
            subprocess.Popen("start excel", shell=True)
            response = "Opening Microsoft Excel."
        elif "powerpoint" in command_text:
            subprocess.Popen("start powerpnt", shell=True)
            response = "Opening Microsoft PowerPoint."
        elif "outlook" in command_text:
            subprocess.Popen("start outlook", shell=True)
            response = "Opening Microsoft Outlook."
        else:
            response = "I couldn't identify which application to open."

        return say(response)
    except Exception as e:
        print(f"Error opening system tool: {e}")
        return say("I had trouble opening that application.")


def process_command(command_text):
    """Process a text command (main function for web interface)"""
    if not command_text:
        return "No command received"

    try:
        command_text = command_text.lower()

        # Check for stop speaking command
        if "stop speaking" in command_text or "shut up" in command_text or "be quiet" in command_text:
            stop_speech()
            return "I'll be quiet now."

        # Check for website opening commands
        websites = [
            ["youtube", "https://www.youtube.com"],
            ["google", "https://www.google.com"],
            ["wikipedia", "https://www.wikipedia.org"]
        ]

        for site in websites:
            if f"open {site[0]}" in command_text:
                webbrowser.open(site[1])
                return say(f"Opening {site[0]}")

        # Check for other commands
        if "search wikipedia" in command_text or "wikipedia" in command_text:
            # Extract the search query (everything after "search wikipedia for" or similar phrases)
            search_terms = command_text.split("wikipedia")[-1].strip()
            if not search_terms and "search" in command_text:
                search_terms = command_text.split("search")[-1].strip()
            return search_wikipedia(search_terms if search_terms else None)

        elif "what is the time" in command_text or "tell me the time" in command_text:
            now = datetime.datetime.now().strftime("%H:%M:%S")
            return say(f"The time is {now}")

        elif "open" in command_text:
            return open_system_tool(command_text)

        elif "shutdown" in command_text or "restart" in command_text:
            return system_power_control(command_text)

        # Default to chat for all other queries
        return chat(command_text)
    except Exception as e:
        print(f"Error processing command: {e}")
        print(traceback.format_exc())
        return say("I'm having trouble processing your request. Please try again.")


def run_voice_assistant():
    """Run the voice assistant in standalone mode"""
    print("AI Assistant Started")
    say("Hello, I am J.A.R.V.I.S Ai")

    while True:
        user_input = take_command()
        if user_input:
            if "exit" in user_input.lower() or "stop" in user_input.lower():
                say("Goodbye!")
                break
            process_command(user_input)


if __name__ == "__main__":
    run_voice_assistant()