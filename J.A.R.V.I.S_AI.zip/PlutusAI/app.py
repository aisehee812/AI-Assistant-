from flask import Flask, render_template, request, jsonify
import sys
import os
import traceback

# Import the assistant module - we'll modify this to handle errors better
try:
    import assistant
except ImportError:
    # Create a simple placeholder if assistant.py isn't ready yet
    class AssistantPlaceholder:
        def process_command(self, text):
            return f"I received your command: {text}. The assistant module is not fully implemented yet."

        def stop_speech(self):
            return {"status": "success", "message": "Speech stopped (placeholder)"}


    assistant = AssistantPlaceholder()

app = Flask(__name__)


@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def process():
    """Process text commands from the web interface"""
    try:
        text = request.json.get('text', '')
        print(f"Received command: {text}")

        # Process the command using your assistant
        try:
            # Try using the process_command function if it exists
            if hasattr(assistant, 'process_command'):
                response = assistant.process_command(text)
            # Otherwise use the chat function directly
            elif hasattr(assistant, 'chat'):
                response = assistant.chat(text)
            else:
                # Fallback response
                response = f"I received your command: {text}. I'm still learning how to respond properly."
        except Exception as e:
            print(f"Error processing command: {e}")
            print(traceback.format_exc())
            # Provide a more user-friendly response
            response = f"I understood that you said: '{text}'. I'm having trouble processing this command right now."

        return jsonify({'response': response})
    except Exception as e:
        print(f"Server error: {e}")
        print(traceback.format_exc())
        return jsonify({'response': "Sorry, I encountered an error. The server team has been notified."})


@app.route('/stop_speech', methods=['POST'])
def stop_speech():
    """Stop the speech synthesis"""
    try:
        result = assistant.stop_speech()
        return jsonify(result)
    except Exception as e:
        print(f"Error stopping speech: {e}")
        print(traceback.format_exc())
        return jsonify({
            'status': 'error',
            'message': 'Failed to stop speech synthesis'
        })


if __name__ == '__main__':
    print(f"Python version: {sys.version}")
    print(f"Current directory: {os.getcwd()}")
    print("Starting Flask server...")
    app.run(debug=True)